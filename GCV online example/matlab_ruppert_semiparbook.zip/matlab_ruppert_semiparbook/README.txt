This folder contains the following programs:

PsplineDR04.m	-	program that computes univariate penalized spline estimates

powerbasis01.m	-	program used by PsplineDR04.m

quantileknots01.m	-	program used by PsplineDR04.m

lidar.dat		-	LIDAR data

lidarprog.m		-	program that calls PsplineDR04.m and plots the fitted curve and minus the estimated derivative.  Also illustrates plotting of prediction and confidence bounds